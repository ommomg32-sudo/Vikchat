import { Hono } from "hono";
import { chatRoutes } from "@/worker/routes/chat";

const app = new Hono<{ Bindings: Env }>();

// Mount chat API routes
app.route("/api/chat", chatRoutes);

// Health check
app.get("/api/health", (c) => {
  return c.json({ status: "ok" });
});

export default app;
