import { Hono } from "hono";

const chatRoutes = new Hono<{ Bindings: Env }>();

// Generate a unique session token
function generateToken(): string {
  return crypto.randomUUID();
}

// Get or create user by session token
async function getOrCreateUser(db: D1Database, sessionToken: string | null) {
  if (sessionToken) {
    const existing = await db
      .prepare("SELECT * FROM chat_users WHERE session_token = ?")
      .bind(sessionToken)
      .first();
    if (existing) return existing;
  }
  
  const newToken = generateToken();
  const result = await db
    .prepare("INSERT INTO chat_users (session_token) VALUES (?) RETURNING *")
    .bind(newToken)
    .first();
  return result;
}

// Find a waiting user to match with
async function findWaitingUser(db: D1Database, excludeUserId: number) {
  return await db
    .prepare("SELECT * FROM chat_users WHERE is_waiting = 1 AND id != ? ORDER BY created_at ASC LIMIT 1")
    .bind(excludeUserId)
    .first();
}

// Join chat / start searching
chatRoutes.post("/join", async (c) => {
  const db = c.env.DB;
  const body = await c.req.json().catch(() => ({}));
  const sessionToken = body.sessionToken || null;
  
  const user = await getOrCreateUser(db, sessionToken);
  if (!user) {
    return c.json({ error: "Failed to create user" }, 500);
  }

  // If user is already in an active chat, return that
  if (user.current_chat_id) {
    const existingChat = await db
      .prepare("SELECT * FROM chat_sessions WHERE id = ? AND is_active = 1")
      .bind(user.current_chat_id)
      .first();
    
    if (existingChat) {
      return c.json({
        sessionToken: user.session_token,
        status: "connected",
        chatId: existingChat.id,
      });
    }
  }

  // Try to find a waiting user
  const waitingUser = await findWaitingUser(db, user.id as number);
  
  if (waitingUser) {
    // Create a chat session between these two users
    const chat = await db
      .prepare("INSERT INTO chat_sessions (user1_id, user2_id) VALUES (?, ?) RETURNING *")
      .bind(waitingUser.id, user.id)
      .first();
    
    if (chat) {
      // Update both users
      await db
        .prepare("UPDATE chat_users SET is_waiting = 0, current_chat_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
        .bind(chat.id, waitingUser.id)
        .run();
      
      await db
        .prepare("UPDATE chat_users SET is_waiting = 0, current_chat_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
        .bind(chat.id, user.id)
        .run();
      
      return c.json({
        sessionToken: user.session_token,
        status: "connected",
        chatId: chat.id,
      });
    }
  }
  
  // No match found, set user as waiting
  await db
    .prepare("UPDATE chat_users SET is_waiting = 1, current_chat_id = NULL, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
    .bind(user.id)
    .run();
  
  return c.json({
    sessionToken: user.session_token,
    status: "searching",
  });
});

// Check status (for polling)
chatRoutes.post("/status", async (c) => {
  const db = c.env.DB;
  const body = await c.req.json().catch(() => ({}));
  const sessionToken = body.sessionToken;
  
  if (!sessionToken) {
    return c.json({ error: "Missing session token" }, 400);
  }
  
  const user = await db
    .prepare("SELECT * FROM chat_users WHERE session_token = ?")
    .bind(sessionToken)
    .first();
  
  if (!user) {
    return c.json({ error: "User not found" }, 404);
  }
  
  if (user.current_chat_id) {
    const chat = await db
      .prepare("SELECT * FROM chat_sessions WHERE id = ? AND is_active = 1")
      .bind(user.current_chat_id)
      .first();
    
    if (chat) {
      return c.json({
        status: "connected",
        chatId: chat.id,
      });
    } else {
      // Chat was ended by the other person
      await db
        .prepare("UPDATE chat_users SET current_chat_id = NULL, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
        .bind(user.id)
        .run();
      
      return c.json({ status: "disconnected" });
    }
  }
  
  if (user.is_waiting) {
    return c.json({ status: "searching" });
  }
  
  return c.json({ status: "idle" });
});

// Send a message
chatRoutes.post("/message", async (c) => {
  const db = c.env.DB;
  const body = await c.req.json().catch(() => ({}));
  const { sessionToken, content } = body;
  
  if (!sessionToken || !content) {
    return c.json({ error: "Missing session token or content" }, 400);
  }
  
  const user = await db
    .prepare("SELECT * FROM chat_users WHERE session_token = ?")
    .bind(sessionToken)
    .first();
  
  if (!user || !user.current_chat_id) {
    return c.json({ error: "Not in an active chat" }, 400);
  }
  
  // Verify chat is still active
  const chat = await db
    .prepare("SELECT * FROM chat_sessions WHERE id = ? AND is_active = 1")
    .bind(user.current_chat_id)
    .first();
  
  if (!chat) {
    return c.json({ error: "Chat is no longer active" }, 400);
  }
  
  // Insert message
  const message = await db
    .prepare("INSERT INTO chat_messages (chat_session_id, sender_id, content) VALUES (?, ?, ?) RETURNING *")
    .bind(chat.id, user.id, content.substring(0, 1000)) // Limit message length
    .first();
  
  return c.json({
    success: true,
    message: {
      id: message?.id,
      content: message?.content,
      isMe: true,
      createdAt: message?.created_at,
    },
  });
});

// Get messages (for polling)
chatRoutes.post("/messages", async (c) => {
  const db = c.env.DB;
  const body = await c.req.json().catch(() => ({}));
  const { sessionToken, lastMessageId } = body;
  
  if (!sessionToken) {
    return c.json({ error: "Missing session token" }, 400);
  }
  
  const user = await db
    .prepare("SELECT * FROM chat_users WHERE session_token = ?")
    .bind(sessionToken)
    .first();
  
  if (!user || !user.current_chat_id) {
    return c.json({ error: "Not in an active chat" }, 400);
  }
  
  // Get messages after lastMessageId (or all if not provided)
  let query = "SELECT * FROM chat_messages WHERE chat_session_id = ?";
  const params: (number | string)[] = [user.current_chat_id as number];
  
  if (lastMessageId) {
    query += " AND id > ?";
    params.push(lastMessageId);
  }
  
  query += " ORDER BY id ASC LIMIT 100";
  
  const messages = await db
    .prepare(query)
    .bind(...params)
    .all();
  
  return c.json({
    messages: (messages.results || []).map((msg: Record<string, unknown>) => ({
      id: msg.id,
      content: msg.content,
      isMe: msg.sender_id === user.id,
      createdAt: msg.created_at,
    })),
  });
});

// Disconnect from current chat
chatRoutes.post("/disconnect", async (c) => {
  const db = c.env.DB;
  const body = await c.req.json().catch(() => ({}));
  const { sessionToken } = body;
  
  if (!sessionToken) {
    return c.json({ error: "Missing session token" }, 400);
  }
  
  const user = await db
    .prepare("SELECT * FROM chat_users WHERE session_token = ?")
    .bind(sessionToken)
    .first();
  
  if (!user) {
    return c.json({ error: "User not found" }, 404);
  }
  
  if (user.current_chat_id) {
    // End the chat session
    await db
      .prepare("UPDATE chat_sessions SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
      .bind(user.current_chat_id)
      .run();
    
    // Clear user's current chat
    await db
      .prepare("UPDATE chat_users SET current_chat_id = NULL, is_waiting = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
      .bind(user.id)
      .run();
  } else {
    // Just stop waiting
    await db
      .prepare("UPDATE chat_users SET is_waiting = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
      .bind(user.id)
      .run();
  }
  
  return c.json({ success: true });
});

// Skip to next (disconnect and immediately search)
chatRoutes.post("/skip", async (c) => {
  const db = c.env.DB;
  const body = await c.req.json().catch(() => ({}));
  const { sessionToken } = body;
  
  if (!sessionToken) {
    return c.json({ error: "Missing session token" }, 400);
  }
  
  const user = await db
    .prepare("SELECT * FROM chat_users WHERE session_token = ?")
    .bind(sessionToken)
    .first();
  
  if (!user) {
    return c.json({ error: "User not found" }, 404);
  }
  
  // End current chat if any
  if (user.current_chat_id) {
    await db
      .prepare("UPDATE chat_sessions SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
      .bind(user.current_chat_id)
      .run();
  }
  
  // Try to find a new match
  const waitingUser = await findWaitingUser(db, user.id as number);
  
  if (waitingUser) {
    // Create new chat session
    const chat = await db
      .prepare("INSERT INTO chat_sessions (user1_id, user2_id) VALUES (?, ?) RETURNING *")
      .bind(waitingUser.id, user.id)
      .first();
    
    if (chat) {
      await db
        .prepare("UPDATE chat_users SET is_waiting = 0, current_chat_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
        .bind(chat.id, waitingUser.id)
        .run();
      
      await db
        .prepare("UPDATE chat_users SET is_waiting = 0, current_chat_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
        .bind(chat.id, user.id)
        .run();
      
      return c.json({
        status: "connected",
        chatId: chat.id,
      });
    }
  }
  
  // No match found, set as waiting
  await db
    .prepare("UPDATE chat_users SET is_waiting = 1, current_chat_id = NULL, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
    .bind(user.id)
    .run();
  
  return c.json({ status: "searching" });
});

// Get online count (approximate)
chatRoutes.get("/online", async (c) => {
  const db = c.env.DB;
  
  // Count users active in last 5 minutes
  const result = await db
    .prepare("SELECT COUNT(*) as count FROM chat_users WHERE updated_at > datetime('now', '-5 minutes')")
    .first();
  
  // Add some base number for appearance
  const realCount = (result?.count as number) || 0;
  const displayCount = Math.max(realCount + 150, 150);
  
  return c.json({ online: displayCount });
});

export { chatRoutes };
